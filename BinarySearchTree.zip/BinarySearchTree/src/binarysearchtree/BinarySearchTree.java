package binarysearchtree;

/**
 *
 * @author Jack 
 */

public class BinarySearchTree<E extends Comparable<E>>
{
    private Node<E> root = null;
    private int size = 0;

    private class Node<E>
    {
        private Integer count = 1;
        private E data = null;
        private Node<E> left = null;
        private Node<E> right = null;
    }

    public void add(E e)
    {
        root = add(root, e);
    }

    private Node<E> add(Node<E> node, E e)
    {
        if(node == null)
        {
            Node<E> newNode = new Node<E>();
            newNode.data = e;
            size++;
            return newNode;
        }
        //go left and search;
        if(node.data.compareTo(e) ==0)
        {
            node.count++;
            return node;
        }
        if(node.data.compareTo(e) > 0)
        {
            node.left = add(node.left, e);
        }
        else
        {
            node.right = add(node.right, e);
        }
        return node;
    }

    public E get(E e)
    {
        return get(root, e);
    }

    private E get(Node<E> node, E e)
    {
        if(node == null)
            return null;
        if(node.data.compareTo(e) == 0)
            return node.data;
        //go left
        else if(node.data.compareTo(e) > 0)
        {
            return get(node.left, e);
        }
        else
        {
            return get(node.right, e);
        }
    }

    public String toString()
    {
        StringBuilder sb = new StringBuilder();
        toString(root, sb);
        return sb.toString();
    }

    private void toString(Node<E> node, StringBuilder sb)
    {
        if(node == null) return ;
        toString(node.left, sb);
        //System.out.printf("%s %d\n",node.data.toString(),node.count);
        sb.append(node.count + "       " + node.data.toString()+ "\n");
        toString(node.right, sb);
    }

    public void remove(E e)
    {
        root = remove(root, e);
    }

    private Node<E> remove(Node<E> node, E e)
    {
        if(node == null) return null;
        //go left subtree
        if(node.data.compareTo(e) > 0)
        {
            node.left=remove(node.left, e);
        }
        else if(node.data.compareTo(e) < 0)
        {
            node.right = remove(node.right, e);
        }
        else
        {
            if(node.left == null && node.right == null)
            {
                size--;
                return null;
            }
            else if(node.right == null)
            {
                size--;
                return node.left;
            }
            else if(node.left == null)
            {
                size--;
                return node.right;
            }
            else
            {
                Node<E> curr = node.left;//go left once
                while(curr.right != null)
                {
                    curr = curr.right;
                }
                node.data = curr.data;
                node.left = remove(node.left, curr.data);
            }
        }
        return node;
    }

}
