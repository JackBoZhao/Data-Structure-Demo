package binarysearchtree;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author Jack
 */
public class BinarySearchDriver
{
    public static void main(String[] args)
    throws FileNotFoundException
    {
        Scanner inF = new Scanner(new File("src/binarysearchtree/animals.txt"));
        BinarySearchTree bst = new BinarySearchTree();
        
        while(inF.hasNextLine())
        {
            bst.add(inF.nextLine());
        }
        System.out.print(bst.toString());
    }
}
