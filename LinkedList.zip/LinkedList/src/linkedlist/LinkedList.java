package linkedlist;

/**
 *
 * @author Jack
 */
public class LinkedList<E> implements Prj3ListInterface<E>
{
    private Node<E> head = null;
    private int size;

    private class Node<E>
    {
        private Node<E> next;
        private E data;
        private Node()
        {
        }

        private Node(E e, Node<E> curr)
        {
            this.data = e;
            this.next = curr;
        }
    }
    public void add(E e)
    {
        Node<E> curr = head;
        if(head == null)
        {
            head = new Node<E>(e, curr);
        }
        else
        {
            while(curr.next != null)
            {
                curr = curr.next;
            }
            /*for(int i = 0; i<size; i++)
            {
            curr = curr.next;
            }*/
            //curr = curr.next;
            curr.next = new Node(e,null);
           // curr.data = e;
        }
        size++;
    }

    public boolean insert(int n, E e)
    {
        if(n < 0 || n > size)
            return false;
        Node<E> node = new Node<E>();
        node.data = e;
        size++;
        if(n==0)
        {
            node.next = head;
            head = node;
        }
        else
        {
            Node<E> curr = head;
            for(int i = 0; i < n - 1; i++)
            {
                curr = curr.next;
            }
            node.next = curr.next;
            curr.next = node;
        }
        return true;
    }

    public E remove(int n)
    {
        if(n < 0 || n >= size)
            return null;
        size--;
        if(n==0)
        {
            E data = head.data;
            head = head.next;
            return data;
        }
        else
        {
            Node<E> curr = head;
            for(int i = 0; i < n - 1; i++)
            {
                curr = curr.next;
            }
            E data = curr.next.data;
            curr.next = curr.next.next;
            return data;
        }
    }

    public boolean isEmpty()
    {
        return size == 0;
    }
         
    public int size()
    {
        return size;
    }

    public E get(int n)
    {
        if(n < 0 || n >= size)
            return null;
        Node<E> curr = head;
        for(int i = 0; i < n; i++)
        {
            curr = curr.next;
        }
        return curr.data;
    }
    public String toString()
    {
        String s = "List has " + size + " elements:\n" + "[";
        for(int i = 0; i < size - 1; i++)
        {
            s = s + get(i) + ",";
        }
        s = s + get(size-1) + "]";
        return s;
    }
}
