package hashmap;

/**
 *
 * @author Jack
 */
public class HashMap
{
    private int capacity = 100;
    private String[] keys = new String[capacity];
    private Object[] table = new Object[capacity];
    private int size = 0;

    public void put(String key, Object value)
    {
        int index = Math.abs(key.hashCode()) % keys.length;

        while(keys[index] != null && (!keys[index].equals(key)))
        {
            index = (index + 1) % keys.length;
        }
        keys[index] = key;
        table[index] = value;
        size++;
    }

    public Object get(String key)
    {
        int index = Math.abs(key.hashCode()) % keys.length;

        while(keys[index] != null && (!keys[index].equals(key)))
        {
            index = (index + 1) % keys.length;
        }
        return table[index];
    }

    public void printObjects()
    {
        System.out.println("The Key  " + "     The Value\n");
        for(int i = 0; i < table.length;i++)
        {
            System.out.printf("%s  %11s\n", keys[i],table[i]);
        }
    }

}
