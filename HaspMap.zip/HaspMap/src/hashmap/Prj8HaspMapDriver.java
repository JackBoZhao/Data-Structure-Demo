package hashmap;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author Jack
 */
public class Prj8HaspMapDriver
{
    public static void main(String[] args)
    throws FileNotFoundException
    {
        Scanner inF = new Scanner(new File("src/hashmap/animals.txt"));
        HashMap hashmap = new HashMap();

        while(inF.hasNextLine())
        {    
            String inf = inF.nextLine();
            if(hashmap.get(inf) != null)
            {
                int count = (int)hashmap.get(inf)+1;
                hashmap.put(inf,  new Integer(count));
            }
            else
                hashmap.put(inf, new Integer(1));

        }   
        hashmap.printObjects();
    }

}
