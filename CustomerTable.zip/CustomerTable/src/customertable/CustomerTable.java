/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package customertable;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Optional;
import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.input.KeyCombination;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.util.Callback;

/**
 *
 * @author Jack
 */
public class CustomerTable extends Application
{
    private ObservableList<ObservableList> tableData;
    private TableView tableView;
    private PreparedStatement pstmt;
    private ResultSet rset;
    private final String mysqlDriver = "com.mysql.jdbc.Driver";
    private String dbconn;
    private Connection conn;
    private Statement stmt;

    private LoginDialog loginDialog;
    private BorderPane bp;
    private MenuBar menuBar;
    private Menu mDatabase;
    protected MenuItem miConnect;
    protected MenuItem miDisconnect;

    protected void fillTableData()
    {
        try
        {
            tableData = FXCollections.observableArrayList();
            for (int i = 0; i < rset.getMetaData().getColumnCount() - 1; i ++)
            {
                final int index = i;
                TableColumn tableColumn
                        = new TableColumn(rset.getMetaData().getColumnName(i + 1));
                tableColumn.setCellValueFactory(new Callback<CellDataFeatures<ObservableList, String>, ObservableValue<String>>()
                {
                    public ObservableValue<String> call(CellDataFeatures<ObservableList, String> p)
                    {
                        return new SimpleStringProperty(p.getValue().get(index).toString());
                    }
                }
                );
                tableView.getColumns().addAll(tableColumn);
                System.out.println("Column[" + i + "] ");
            }
            while (rset.next())
            {
                ObservableList<String> row = FXCollections.observableArrayList();
                for (int i = 1; i < rset.getMetaData().getColumnCount(); i ++)
                {
                    row.add(rset.getString(i));
                }
                System.out.println("Row [1] added " + row);
                tableData.add(row);
            }
            tableView.setItems(tableData);
        }
        catch (Exception e)
        {
            System.out.println("somthing's wrong when filling tableData:");
            e.printStackTrace();
        }
    }

    protected void initDB(Optional<ButtonType> btnResult)
    {
        if (btnResult.get() == ButtonType.OK)
        {

            try
            {
                Class.forName(mysqlDriver);
                dbconn = "jdbc:mysql://localhost/tutorials";
                conn = DriverManager.getConnection(dbconn, "root", loginDialog.getPassword());
                stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
                pstmt = conn.prepareStatement(
                        "select * from customer;", ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
                rset = pstmt.executeQuery();
            }
            catch (ClassNotFoundException cnfe)
            {
                System.out.println("cnfe");
                cnfe.printStackTrace();
            }
            catch (SQLException sqle)
            {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error Dialog");
                alert.setHeaderText(null);
                alert.setContentText("Connection is not successful, please try again!");
                alert.showAndWait();
                //System.out.println("sqle");
                sqle.printStackTrace();
            }
        }
        else if (btnResult.get() == ButtonType.CANCEL)
        {
            return;
        }
    }

    protected void disconnectDB()
    {
        try
        {
            rset.close();
            pstmt.close();
            conn.close();
        }
        catch (SQLException sqle)
        {
            System.out.println("sqle: ");
            sqle.printStackTrace();
        }
        tableView = new TableView();
        bp.setCenter(tableView);
    }
    
    protected void updateTable()
    {
        fillTableData();
    }

    @Override
    public void start(Stage primaryStage)
    {
        tableView = new TableView();
        bp = new BorderPane();
        menuBar = new MenuBar();
        mDatabase = new Menu("_Database");
        miConnect = new MenuItem("_Connect");
        miConnect.setAccelerator(KeyCombination.keyCombination("CTRL+O"));
        miDisconnect = new MenuItem("_Disconnect");
        miDisconnect.setAccelerator(KeyCombination.keyCombination("CTRL+S"));
        miDisconnect.setDisable(true);

        mDatabase.getItems().add(miConnect);
        mDatabase.getItems().add(miDisconnect);
        menuBar.getMenus().add(mDatabase);
        bp.setTop(menuBar);
        bp.setCenter(tableView);

        Scene scene = new Scene(bp);
        primaryStage.setTitle("Table View");
        primaryStage.setScene(scene);
        primaryStage.show();

        miConnect.setOnAction(e
                -> 
                {
                    loginDialog = new LoginDialog();
                    Optional<ButtonType> btnResult = loginDialog.showAndWait();
                    initDB(btnResult);
                    fillTableData();
                    miConnect.setDisable(true);
                    miDisconnect.setDisable(false);
        });
        miDisconnect.setOnAction(e
                -> 
                {
                    disconnectDB();
                            miConnect.setDisable(false);
                            miDisconnect.setDisable(true);
        });
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        launch(args);
    }

}
