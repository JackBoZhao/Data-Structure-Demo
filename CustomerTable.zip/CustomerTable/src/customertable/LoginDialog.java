package customertable;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Dialog;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Labeled;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;

/**
 *
 * @author Jack
 */
public class LoginDialog extends Dialog<ButtonType>
{
    private ComboBox<String> cboHostName;
    private ComboBox<String> cboDBName;
    private ComboBox<String> cboUserType;
    private TextField tfuserName;
    private final TextField passwordField = new PasswordField();
    private TextField tfTableName;
    private String[] servers =
    {
        "MySQL", "Mircrosoft Server", "Oracle", "IBM"
    };
    private String[] dbNames =
    {
        "Tutorials", "School", "JDBC", "WebServices"
    };
    private String[] userType =
    {
        "Admin", "Normal", "Visitor"
    };
    private Button btnLogin;
    private Button btnCancle;
    private Label lservers;
    private Label ldbNames;
    private Label luserType;
    private Label luserName;
    private Label lpassword;
    private Label lTableName;
    private HBox hBoxHostName;
    private HBox hBoxDBName;
    private HBox hbUserType;
    private HBox hBoxUser;
    private HBox hBoxPassword;
    private HBox hBoxLogin;
    private HBox hbTableName;
    private FlowPane flowPane;
    private GridPane gp;
    private BorderPane bp;

    protected LoginDialog()
    {
        setTitle("Login Dialog");
        setHeaderText("Please Login:");

        //initialize the data
        ObservableList<String> sservers = FXCollections.observableArrayList(servers);
        ObservableList<String> sdbNames = FXCollections.observableArrayList(dbNames);
        ObservableList<String> suserType = FXCollections.observableArrayList(userType);
        gp = new GridPane();
        bp = new BorderPane();
        cboHostName = new ComboBox<>();
        cboDBName = new ComboBox<>();
        cboUserType = new ComboBox<>();
        cboHostName.getItems().addAll(sservers);
        cboHostName.setValue(sservers.get(0));
        cboDBName.getItems().addAll(sdbNames);
        cboDBName.setValue(sdbNames.get(0));
        cboUserType.getItems().addAll(suserType);
        cboUserType.setValue(suserType.get(0));
        tfuserName = new TextField();
        tfTableName = new TextField("customer");
        btnLogin = new Button("Login");
        btnCancle = new Button("Cancle");
        lservers = new Label("Database Server:");
        ldbNames = new Label("Select Database:");
        luserType = new Label("User Type");
        luserName = new Label("User Name:");
        lpassword = new Label("Password:");
        lTableName = new Label("Table Name");
        hBoxHostName = new HBox(15);
        hBoxDBName = new HBox(15);
        hBoxUser = new HBox(20);
        hBoxPassword = new HBox(15);
        hBoxLogin = new HBox(15);
        hbUserType = new HBox(15);
        hbTableName = new HBox(15);

        //Components Style
        hBoxHostName.setPadding(new Insets(5, 5, 5, 5));
        hBoxDBName.setPadding(new Insets(5, 5, 5, 5));
        hBoxUser.setPadding(new Insets(5, 5, 5, 5));
        hBoxPassword.setPadding(new Insets(5, 5, 5, 5));
        hBoxLogin.setPadding(new Insets(5, 5, 5, 5));

        gp.setVgap(12);
        gp.setHgap(5);
        gp.add(lservers, 0, 0);
        gp.add(cboHostName, 1, 0);
        gp.add(ldbNames, 0, 1);
        gp.add(cboDBName, 1, 1);
        gp.add(lTableName, 0, 2);
        gp.add(tfTableName, 1, 2);
        gp.add(luserType, 0, 3);
        gp.add(cboUserType, 1, 3);
        gp.add(luserName, 0, 4);
        gp.add(tfuserName, 1, 4);
        gp.add(lpassword, 0, 5);
        gp.add(passwordField, 1, 5);

        getDialogPane().setContent(gp);
        getDialogPane().getButtonTypes().add(ButtonType.OK);
        getDialogPane().getButtonTypes().add(ButtonType.CANCEL);
    }

    protected String getHostName()
    {
        String hostName = null;
        if (cboHostName.getValue().equalsIgnoreCase("MySQL"))
        {
            hostName = "localhost";
        }
        return hostName;

    }

    protected String getDBName()
    {
        return cboDBName.getValue();
    }

    protected String getUsername()
    {
        return tfuserName.getText();
    }

    protected String getPassword()
    {
        return passwordField.getText();
    }

    protected String getTablename()
    {
        return tfTableName.getText();
    }
}
