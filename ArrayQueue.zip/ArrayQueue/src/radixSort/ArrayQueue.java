package radixSort;

/**
 *
 * @author Jack
 */

public class ArrayQueue<E>
{
    private int size = 0;
    private E[] queue;
    private int rear = -1;
    private int front = 0;

    public ArrayQueue()
    {
        queue = (E[])new Object[10];
    }

    public void enqueue(E e)
    {
        if(size == queue.length)
            reallocate();
        rear = (rear + 1) % queue.length;
        queue[rear] = e;
        size++;
    }

    public E dequeue()
    {
        if(size == 0)
            return null;
        E e = queue[front];
        front = (front + 1) % queue.length;
        size--;
        return e;
    }

    public void reallocate()
    {

            E[] temp = (E[]) new Object[2*size];
            int i = 0;
            while(!isEmpty())
            {
                temp[i] = dequeue();
                i++;
            }
            front = 0;
            rear = i - 1;
            size = i;
            queue = temp;

    }
    
    public E peek()
    {
        return queue[front];
    }
    
    public int size()
    {
        return this.size;
    }

    public boolean isEmpty()
    {
        return size==0;
    }
}

