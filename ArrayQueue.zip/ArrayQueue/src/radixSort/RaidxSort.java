package radixSort;

/**
 *
 * @author Jack
 */
import java.util.*;
import java.io.*;

public class RaidxSort
{
    public static void main(String[] args)
    throws FileNotFoundException
    {
        Scanner inF = new Scanner(new File("src/radixSort/radixSortData.txt"));
        ArrayQueue[] queue = {new ArrayQueue(), new ArrayQueue(),
                new ArrayQueue(), new ArrayQueue(), new ArrayQueue(),
                new ArrayQueue(), new ArrayQueue(), new ArrayQueue(), 
                new ArrayQueue(), new ArrayQueue(), new ArrayQueue()};

        ArrayList<String> list = new ArrayList<>();
        ArrayList<String> list2 = new ArrayList<>();
        ArrayList<String> list3 = new ArrayList<>();
        ArrayList<String> list4 = new ArrayList<>();

        for(int i = 0; inF.hasNext(); i++)
        {
            list.add(inF.nextLine());
        }

        for(int i = 0; i < list.size(); i++)
        {
            String t = list.get(i).charAt(2) + "";
            queue[Integer.parseInt(t)].enqueue(list.get(i));
        }

        for(int i = 0; i <queue.length; i++)
        {
            int n = 0;
            while(n < queue[i].size())
            {
                list2.add((String)queue[i].dequeue());
            }
        }
        System.out.print("After comparing the last digit: " );
        
        for(int i = 0; i < list2.size(); i++)
        {
            if(i%14==0)
            System.out.println();
            System.out.print(list2.get(i) + " ");
        }

        //Compare the second digit from the last sorted list
        for(int i = 0; i < list.size(); i++)
        {
            String t = list2.get(i).charAt(1) + "";
            queue[Integer.parseInt(t)].enqueue(list2.get(i));
        }
        System.out.println("\n");

        for(int i = 0; i <queue.length; i++)
        {
            int n = 0;
            while(n < queue[i].size())
            {
                list3.add((String)queue[i].dequeue());
            }
        }
        System.out.print("After comparing the middle digit: " );
        
        for(int i = 0; i < list2.size(); i++)
        {
            if(i%14==0)
                System.out.println();
            System.out.print(list3.get(i) + " ");
        }

        //This is the third time
        for(int i = 0; i < list.size(); i++)
        {
            String t = list3.get(i).charAt(0) + "";
            queue[Integer.parseInt(t)].enqueue(list3.get(i));
        }
        System.out.println("\n");

        for(int i = 0; i <queue.length; i++)
        {
            int n = 0;
            while(n < queue[i].size())
            {
                list4.add((String)queue[i].dequeue());
            }
        }
        System.out.print("After comparing the first digit: " );
        
        for(int i = 0; i < list2.size(); i++)
        {
            if(i%14==0)
                System.out.println();
            System.out.print(list4.get(i) + " ");
        }
    }
}

    